//This is a program that a hardware store might use to represent an invoice for an item sold at the store.

#include <iostream>

using namespace std;

//Class Invoice definition.			
class Invoice{
	private:
		
		//Data members
		string partNumber;			
		string partDescription;
		int quantity;
		float pricePerItem;
	public:
		//Default constructor for initializing the data members.
		Invoice();
		
		//Function for setting the part number.
		//Params: part_number (string)
		//Returns: void
		void setPartNumber(string part_number);
		
		//Function for setting part description
		//Params: part_description (string)
		//Returns: void
		void setPartDescription(string part_description);
		
		//Function for setting quantity. 
		//If item_quantity is less than 0. Print error message. Set quantity to 0.
		//Otherwise, set the quantity value.
		//Params: item_quantity (int)
		//Returns: void
		void setQuantity(int item_quantity);
		
		//Function for setting price per item.
		//If price_per_item is less than 0. Print error message. Set price Per Item to 0.
		//Otherwise, set the price Per Item value.
		//Params: price_per_item (float)
		//Returns: void
		void setPricePerItem(float price_per_item);
		
		//Function that returns the part number.
		//Returns: part number (string)
		string getPartNumber();
		
		//Function that returns the description.
		//Returns: part description (string)
		string getPartDescription();
		
		//Function that returns the quantity.
		//Returns: quantity (int)
		int getQuantity();
		
		//Function that returns the price per item.
		//Returns: price per item (int)
		float getPricePerItem();
		
		//Function that computes and returns the invoice amount.
		//Returns: invoice amount (float)
		float getInvoiceAmount();
};



//Default constructor for initializing the data members.
Invoice::Invoice(){
	partNumber = "";
	partDescription = "";
	quantity = 0;
	pricePerItem = 0;
}
		
//Function for setting the part number.
//Params: string
//Returns: void
void Invoice::setPartNumber(string part_number){
	partNumber = part_number;
}

//Function for setting part description
//Params: string
//Returns: void
void Invoice::setPartDescription(string part_description){
	partDescription = part_description;
}

//Function for setting quantity. 
//Params: int
//Returns: void
void Invoice::setQuantity(int item_quantity){
	//If item_quantity is less than 0.
	if(item_quantity < 0){
		//Print error message.
		cout << "\nQuantity cannot be negative. Quantity set to 0. Invoice data members modified.\n" << endl;
		//Set quantity to 0.
		quantity = 0;
	}
	//Otherwise, set the quantity value.
	else{
		quantity = item_quantity;
	}
}

//Function for setting price per item.
//Params: price_per_item (int)
//Returns: void
void Invoice::setPricePerItem(float price_per_item){
	//If price_per_item is less than 0.
	if(price_per_item < 0){
		//Print error message.
		cout << "\nPrice cannot be negative. Price set to 0. Invoice data members modified.\n" << endl;
		// Set price Per Item to 0.
		pricePerItem = 0;
	}
	//Otherwise, set the price per item value.
	else{
		pricePerItem = price_per_item;
	}
}

//Function that returns the part number.
//Returns: part number (string)
string Invoice::getPartNumber(){
	return partNumber;
}

//Function that returns the description.
//Returns: part description (string)
string Invoice::getPartDescription(){
	return partDescription;
}

//Function that returns the quantity.
//Returns: quantity (int)
int Invoice::getQuantity(){
	return quantity;	
}

//Function that returns the price per item.
//Returns: price per item (float)
float Invoice::getPricePerItem(){
	return pricePerItem;
}

//Function that computes and returns the invoice amount.
float Invoice::getInvoiceAmount(){
	//Returns the computed invoice amount.
	return quantity*pricePerItem;
}


//Application to demonstrate the capabilities of class Invoice.
int main(){
	//Decleration
	Invoice invoice;			//For accessing Invoice data members.
	string part_number;			//For storing part number
	string part_description;	//For storing part description.
	int item_quantity;			//For storing item quantity.
	float price_per_item;		//For storing price per item.
	
	//Ask for user input.
	cout << "Enter part number: ";		//Prompt user to enter the part number
	cin >> part_number;					//Input the inserted value in part_number.
	cout << "Enter description: ";		//Prompt user to enter the description.
	cin >> part_description;			//Input the inserted value in part_description.
	cout << "Enter quantity: ";			//Prompt user to enter the quantity.
	cin >> item_quantity;				//Input the inserted value in item_quantity.
	cout << "Enter price per item: R";	//Prompt user to enter price per item.
	cin >> price_per_item;				//Input the inserted value in price_per_item.
	system("cls");						//Clear the screen.
	
	//Setting the values using the setters.
	invoice.setPartNumber(part_number);				//Set the part number.
	invoice.setPartDescription(part_description);	//Set the description.
	invoice.setQuantity(item_quantity);				//Set the quantity.
	invoice.setPricePerItem(price_per_item);		//Set the price per item.
	
	//Printing the summery.
	cout << "****************************************************" <<endl;
	cout << "\t\t\tINVOICE" << endl;
	cout << "****************************************************" <<endl;
	cout << "Part number	: " << invoice.getPartNumber() << endl;		//Print part number.
	cout << "Decription	: "	<< invoice.getPartDescription() << endl;	//Print description.
	cout << "Quantity	: " << invoice.getQuantity() << endl;			//Print quantity
	cout << "Price per item	: R" << invoice.getPricePerItem() << endl;	//Print price per item.
	cout << "Invoice amount	: R" << invoice.getInvoiceAmount() << endl;	//Print invoice amount.
	cout << "****************************************************" <<endl;
}
